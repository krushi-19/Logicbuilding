#include <stdio.h>

int main() {
 int a[5] = {10,20,30,40,50};
 printf("*a is %d *(a+1) is %d", *a, *(a+1));
 printf("*a is %d *a+1 is %d", *a, *a+1);
 printf("\n %d", *(a+2)+6);
 printf(" \n %d", *a+3+4);
 printf("\n %d", *(a+1)+*(a+3));


  return 0;
}